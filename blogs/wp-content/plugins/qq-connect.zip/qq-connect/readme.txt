﻿=== Plugin Name ===
Contributors: denishua
Donate link: http://fairyfish.net/donate/
Tags: QQ,Connect
Requires at least: 2.8
Tested up to: 3.0
Stable tag: 2.2

使用腾讯微博瓣账号登陆你的 WordPress 博客，博主可以同步日志到腾讯微博，用户可以同步留言到腾讯微博。

== Description ==

使用腾讯微博瓣账号登陆你的 WordPress 博客，并且留言使用腾讯微博的头像。博主可以同步日志到腾讯微博，用户可以同步留言到腾讯微博。

详细介绍： http://fairyfish.net/2010/12/20/qq-connect/

== Installation ==

上传激活即可。详细安装请点击：  http://fairyfish.net/2010/12/20/qq-connect/


== Changelog ==

= 1.0 - 初始版本